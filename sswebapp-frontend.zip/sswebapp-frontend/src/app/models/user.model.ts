export interface UserLogin {
  userName: string;
  password: string;
}

export interface UserSignup {
  userName: string;
  password: string;
  confirmPassword: string;
}