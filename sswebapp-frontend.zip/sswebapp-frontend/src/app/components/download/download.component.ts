import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.scss']
})
export class DownloadComponent {
  userName: string = "";
  files: any = [];

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.userName = localStorage.getItem("userName") ?? "";

    if (!localStorage.getItem("token")) {
      this.router.navigateByUrl("/login");
    }

    this.loadFiles();
  }

  loadFiles() {
    this.userService.getAllFiles(localStorage.getItem("token") ?? "").subscribe((res: any) => { this.files = res.files; }, err => { console.log(err) });
  }


  logout() {
    localStorage.clear();
    this.router.navigateByUrl("/login");
  }

  moveToUploads() {
    this.router.navigateByUrl("/upload");
  }

}
